import os
import glob

# Using os.listdir()
dir_path = '.'
files = os.listdir(dir_path)

# Using os.walk()
for root, dirs, files in os.walk(dir_path):
    for file in files:
        pos = file.find('月')
        if pos > 0:
            new_name = 'H%04d%02d' % (int(file[:3])+1911, int(file[4:pos])) + '.ods'
            os.rename(file, new_name)
            # print(file, new_name)
